﻿Archivo de prueba para esquematico.
